document.addEventListener("DOMContentLoaded", function () {
    const inputField = document.querySelector("input");
    const buttons = document.querySelectorAll(".buttons button");
  
    buttons.forEach((button) => {
      button.addEventListener("click", handleButtonClick);
    });
  
    function handleButtonClick() {
      const buttonText = this.textContent;
  
      switch (buttonText) {
        case "=":
          try {
            inputField.value = eval(inputField.value);
          } catch (error) {
            inputField.value = "Error";
          }
          break;
        case "C":
          inputField.value = "";
          break;
        case "!":
          inputField.value = factorial(parseInt(inputField.value));
          break;
        case "√":
          inputField.value = Math.sqrt(parseFloat(inputField.value));
          break;
        case "x²":
          inputField.value = Math.pow(parseFloat(inputField.value), 2);
          break;
        case "sin":
          inputField.value = Math.sin(parseFloat(inputField.value));
          break;
        case "cos":
          inputField.value = Math.cos(parseFloat(inputField.value));
          break;
        case "log":
          inputField.value = Math.log10(parseFloat(inputField.value));
          break;
        default:
          if (inputField.value === "Error") {
            inputField.value = buttonText;
          } else {
            inputField.value += buttonText;
          }
          break;
      }
    }
  
    function factorial(num) {
      if (num === 0 || num === 1) return 1;
      for (let i = num - 1; i >= 1; i--) {
        num *= i;
      }
      return num;
    }
  });
